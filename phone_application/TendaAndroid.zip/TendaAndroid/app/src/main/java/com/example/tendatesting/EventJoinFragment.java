package com.example.tendatesting;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class EventJoinFragment extends Fragment {
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){
        getActivity().setTitle("Search / Join Event");

        final View v = inflater.inflate(R.layout.fragment_event_join, container, false);
        final String userID = getArguments().getString("userID");
        Log.d("JoinLog", userID);

        Button eventButton = v.findViewById(R.id.search_button);
        final EditText search = (EditText)v.findViewById(R.id.search);
        final TextView nameResult = v.findViewById(R.id.nameValue);
        final TextView descriptionResult = v.findViewById(R.id.descriptionValue);
        final TextView timeResult = v.findViewById(R.id.timeValue);
        final TextView dateResult = v.findViewById(R.id.dateValue);

        final String[] event_id = {"null"};

        eventButton.setOnClickListener( new View.OnClickListener() {
            @Override public void onClick(View v) {
                //Format what is needed for request: place to go if verified, a request queue to send a request to the server, and url for server.
                RequestQueue queue = Volley.newRequestQueue(getActivity());
                String eventID = search.getText().toString();
                String url ="http://34.217.162.221:8000/event/"+eventID+"/";
                //Create request
                final StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    //When the request is recieved:
                    @Override
                    public void onResponse(String response) {
                        try {
                            //Convert response to a json
                            JSONObject jsonObj = new JSONObject(response.toString());
                            String result = jsonObj.getString("result");
                            JSONObject event = new JSONObject(result);
                            nameResult.setText(event.getString("name"));
                            dateResult.setText(event.getString("date"));
                            String duration = event.getString("duration");
                            String radius = event.getString("radius");
                            event_id[0] = event.getString("event_id");
                            Log.d("JoinLog", event_id[0]);
                            timeResult.setText(event.getString("time"));
                            descriptionResult.setText(event.getString("description"));
                            Log.d("JoinLog", event.getString("name") + " - " + event.getString("date") + " - " + duration + " - " + radius + " - " + event.getString("time") + " - " + event.getString("description"));
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("ERROR", "Error with request response.");
                    }
                });
                // Add the request to the RequestQueue.
                queue.add(stringRequest);
            }
        });

        Button joinButton = v.findViewById(R.id.join_event);
        joinButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Log.d("JoinLog", "detected button click");

                RequestQueue queue = Volley.newRequestQueue(getActivity());
                String url ="http://34.217.162.221:8000/createResponse";
                //Create request
                final StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                    //When the request is recieved:
                    @Override
                    public void onResponse(String response) {
                        try {
                            //Convert response to a json and check if the response what 200 (which means password is valid)
                            JSONObject jsonObj = new JSONObject(response.toString());
                            String result = jsonObj.getString("result");    //response.toString();
                            Log.d("JoinLog", result);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("ERROR", "Error with request response.");
                    }
                }) {
                    protected Map<String, String> getParams() {
                        //Format data that will make up the body of the post request (email and password)
                        Map<String, String> MyData = new HashMap<String, String>();
                        MyData.put("response", "yes");
                        MyData.put("event_id", event_id[0]);
                        MyData.put("user_id", userID);
                        return MyData;
                    }
                };
                // Add the request to the RequestQueue.
                queue.add(stringRequest);



            }
        });



        return v;
    }
}